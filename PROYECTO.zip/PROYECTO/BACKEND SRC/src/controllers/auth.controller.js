const User = require('../models/User');
const jwt = require('jsonwebtoken');

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) return res.status(400).json({ error: 'Falta email o contraseña' });

    const results = await User.findByEmail(email);
    if (!results || results.length === 0) return res.status(400).json({ error: 'Usuario no encontrado' });

    const user = results[0];

    if (password !== user.password) return res.status(400).json({ error: 'Contraseña incorrecta' });

    const token = jwt.sign({ id: user.id, rol: user.rol }, 'MI_SECRETO_SUPER', { expiresIn: '1d' });

    res.json({ token, user: { id: user.id, nombre: user.nombre, apellido: user.apellido, rol: user.rol } });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};
