const Producto = require('../models/Producto');

exports.getAll = (req, res) => {
  Producto.getAll((err, results) => {
    if (err) return res.status(500).json({ error: 'Error al obtener productos' });
    res.json(results);
  });
};

exports.create = (req, res) => {
  const { nombre, descripcion, precio, stock, proveedor } = req.body;
  Producto.create({ nombre, descripcion, precio, stock, proveedor }, (err, results) => {
    if (err) return res.status(500).json({ error: 'Error al crear producto' });
    res.json({ message: 'Producto creado' });
  });
};

exports.update = (req, res) => {
  const { id } = req.params;
  const { nombre, descripcion, precio, stock, proveedor } = req.body;
  Producto.update(id, { nombre, descripcion, precio, stock, proveedor }, (err, results) => {
    if (err) return res.status(500).json({ error: 'Error al actualizar producto' });
    res.json({ message: 'Producto actualizado' });
  });
};

exports.delete = (req, res) => {
  const { id } = req.params;
  Producto.delete(id, (err, results) => {
    if (err) return res.status(500).json({ error: 'Error al eliminar producto' });
    res.json({ message: 'Producto eliminado' });
  });
};
