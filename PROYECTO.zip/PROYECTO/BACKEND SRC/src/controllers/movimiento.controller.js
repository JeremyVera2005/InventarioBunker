const db = require("../config/db");

// Obtener todos los movimientos con stock actual
const getMovimientos = (req, res) => {
  const sql = `
    SELECT m.id, m.producto_nombre, m.tipo, m.cantidad, m.fecha, p.stock 
    FROM movimientos m
    LEFT JOIN productos p ON m.producto_nombre = p.nombre
    ORDER BY m.fecha DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("❌ Error en getMovimientos:", err);
      return res.status(500).json({ error: "Error al obtener movimientos" });
    }
    res.json(results);
  });
};

// Registrar un nuevo movimiento y actualizar stock
const registrarMovimiento = (req, res) => {
  const { producto_nombre, tipo, cantidad } = req.body;

  if (!["Ingreso", "Salida"].includes(tipo)) {
    return res.status(400).json({ error: "El tipo debe ser 'Ingreso' o 'Salida'" });
  }

  const sqlInsert = "INSERT INTO movimientos (producto_nombre, tipo, cantidad) VALUES (?, ?, ?)";
  db.query(sqlInsert, [producto_nombre, tipo, cantidad], (err, result) => {
    if (err) {
      console.error("❌ Error en registrarMovimiento:", err);
      return res.status(500).json({ error: "Error al registrar movimiento" });
    }

    // Actualizar stock según el tipo
    const sqlUpdate =
      tipo === "Ingreso"
        ? "UPDATE productos SET stock = stock + ? WHERE nombre = ?"
        : "UPDATE productos SET stock = stock - ? WHERE nombre = ?";

    db.query(sqlUpdate, [cantidad, producto_nombre], (err2) => {
      if (err2) {
        console.error("❌ Error al actualizar stock:", err2);
        return res.status(500).json({ error: "Movimiento registrado pero no se actualizó el stock" });
      }

      res.json({ message: "✅ Movimiento registrado y stock actualizado", id: result.insertId });
    });
  });
};

// Editar un movimiento existente
const updateMovimiento = (req, res) => {
  const { id } = req.params;
  const { producto_nombre, tipo, cantidad } = req.body;

  if (!["Ingreso", "Salida"].includes(tipo)) {
    return res.status(400).json({ error: "El tipo debe ser 'Ingreso' o 'Salida'" });
  }

  // Obtener el movimiento original
  db.query("SELECT * FROM movimientos WHERE id = ?", [id], (err, rows) => {
    if (err) return res.status(500).json({ error: "Error al obtener movimiento" });
    if (rows.length === 0) return res.status(404).json({ error: "Movimiento no encontrado" });

    const movimientoOriginal = rows[0];

    // Revertir el stock anterior
    const revertSQL =
      movimientoOriginal.tipo === "Ingreso"
        ? "UPDATE productos SET stock = stock - ? WHERE nombre = ?"
        : "UPDATE productos SET stock = stock + ? WHERE nombre = ?";

    db.query(revertSQL, [movimientoOriginal.cantidad, movimientoOriginal.producto_nombre], (err2) => {
      if (err2) return res.status(500).json({ error: "Error al revertir stock anterior" });

      // Actualizar el movimiento
      const sqlUpdateMov = "UPDATE movimientos SET producto_nombre = ?, tipo = ?, cantidad = ? WHERE id = ?";
      db.query(sqlUpdateMov, [producto_nombre, tipo, cantidad, id], (err3) => {
        if (err3) return res.status(500).json({ error: "Error al actualizar movimiento" });

        // Aplicar el nuevo stock
        const applySQL =
          tipo === "Ingreso"
            ? "UPDATE productos SET stock = stock + ? WHERE nombre = ?"
            : "UPDATE productos SET stock = stock - ? WHERE nombre = ?";

        db.query(applySQL, [cantidad, producto_nombre], (err4) => {
          if (err4) return res.status(500).json({ error: "Movimiento actualizado pero stock no ajustado" });

          res.json({ message: "✅ Movimiento actualizado y stock ajustado" });
        });
      });
    });
  });
};

// Eliminar un movimiento y revertir stock
const deleteMovimiento = (req, res) => {
  const { id } = req.params;

  db.query("SELECT * FROM movimientos WHERE id = ?", [id], (err, rows) => {
    if (err) return res.status(500).json({ error: "Error al buscar movimiento" });
    if (rows.length === 0) return res.status(404).json({ error: "Movimiento no encontrado" });

    const movimiento = rows[0];

    // Revertir stock
    const revertSQL =
      movimiento.tipo === "Ingreso"
        ? "UPDATE productos SET stock = stock - ? WHERE nombre = ?"
        : "UPDATE productos SET stock = stock + ? WHERE nombre = ?";

    db.query(revertSQL, [movimiento.cantidad, movimiento.producto_nombre], (err2) => {
      if (err2) return res.status(500).json({ error: "Error al revertir stock" });

      // Eliminar movimiento
      db.query("DELETE FROM movimientos WHERE id = ?", [id], (err3) => {
        if (err3) return res.status(500).json({ error: "Error al eliminar movimiento" });
        res.json({ message: "🗑️ Movimiento eliminado y stock revertido" });
      });
    });
  });
};

module.exports = {
  getMovimientos,
  registrarMovimiento,
  updateMovimiento,
  deleteMovimiento,
};
