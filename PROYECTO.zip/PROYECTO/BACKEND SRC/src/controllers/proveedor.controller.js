const Proveedor = require('../models/Proveedor');

exports.getAll = (req, res) => {
  Proveedor.getAll((err, results) => {
    if (err) return res.status(500).json({ error: 'Error al obtener proveedores' });
    res.json(results);
  });
};

exports.create = (req, res) => {
  const { nombre, contacto, telefono } = req.body;
  Proveedor.create({ nombre, contacto, telefono }, (err, results) => {
    if (err) return res.status(500).json({ error: 'Error al crear proveedor' });
    res.json({ message: 'Proveedor creado' });
  });
};

exports.update = (req, res) => {
  const { id } = req.params;
  const { nombre, contacto, telefono } = req.body;
  Proveedor.update(id, { nombre, contacto, telefono }, (err, results) => {
    if (err) return res.status(500).json({ error: 'Error al actualizar proveedor' });
    res.json({ message: 'Proveedor actualizado' });
  });
};

exports.delete = (req, res) => {
  const { id } = req.params;
  Proveedor.delete(id, (err, results) => {
    if (err) return res.status(500).json({ error: 'Error al eliminar proveedor' });
    res.json({ message: 'Proveedor eliminado' });
  });
};
