const db = require("../config/db");

const Movimiento = {
  // Obtener todos los movimientos
  getAll: (cb) =>
    db.query(
      `SELECT id, producto_nombre, tipo, cantidad, fecha 
       FROM movimientos 
       ORDER BY fecha DESC`,
      cb
    ),

  // Crear movimiento (producto_nombre, tipo, cantidad)
  create: (data, cb) =>
    db.query(
      "INSERT INTO movimientos (producto_nombre, tipo, cantidad) VALUES (?, ?, ?)",
      [data.producto_nombre, data.tipo, data.cantidad],
      cb
    ),

  // ⚠️ Nota: realmente no deberías permitir update de movimientos (solo registrar y eliminar).
  update: (id, data, cb) =>
    db.query(
      "UPDATE movimientos SET producto_nombre=?, tipo=?, cantidad=? WHERE id=?",
      [data.producto_nombre, data.tipo, data.cantidad, id],
      cb
    ),

  delete: (id, cb) =>
    db.query("DELETE FROM movimientos WHERE id=?", [id], cb),
};

module.exports = Movimiento;
