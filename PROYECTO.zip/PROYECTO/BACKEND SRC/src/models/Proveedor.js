const db = require("../config/db");

const Proveedor = {
  getAll: (cb) => db.query("SELECT * FROM proveedores", cb),
  create: (data, cb) => db.query("INSERT INTO proveedores SET ?", data, cb),
  update: (id, data, cb) => db.query("UPDATE proveedores SET ? WHERE id = ?", [data, id], cb),
  delete: (id, cb) => db.query("DELETE FROM proveedores WHERE id = ?", [id], cb),
};

module.exports = Proveedor;
