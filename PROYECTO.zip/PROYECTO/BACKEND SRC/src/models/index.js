const Sequelize = require('sequelize');
const sequelize = require('../config/db');


const User = require('./User')(sequelize);
const Producto = require('./Producto')(sequelize);
const Proveedor = require('./Proveedor')(sequelize);
const Movimiento = require('./Movimiento')(sequelize);


// Relaciones
Proveedor.hasMany(Producto, { foreignKey: 'proveedorId' });
Producto.belongsTo(Proveedor, { foreignKey: 'proveedorId' });


Producto.hasMany(Movimiento, { foreignKey: 'productoId' });
Movimiento.belongsTo(Producto, { foreignKey: 'productoId' });


module.exports = {
sequelize,
User,
Producto,
Proveedor,
Movimiento
};