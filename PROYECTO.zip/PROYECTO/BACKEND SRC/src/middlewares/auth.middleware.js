const jwt = require('jsonwebtoken');
require('dotenv').config(); // Para leer la variable JWT_SECRET de .env

module.exports = (req, res, next) => {
    // Revisar el header Authorization
    const header = req.headers['authorization'];
    if (!header) return res.status(401).json({ message: 'No autorizado' });

    // El token viene con formato "Bearer <token>"
    const token = header.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'No autorizado' });

    try {
        // Verificar token
        const data = jwt.verify(token, process.env.JWT_SECRET || 'secret');
        req.user = data; // Guardamos la info del usuario en req.user
        next(); // Pasar al siguiente middleware o ruta
    } catch (err) {
        res.status(401).json({ message: 'Token inválido' });
    }
};
