const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',          // Tu usuario MySQL
  password: '',          // Tu contraseña MySQL
  database: 'inventario' // Tu base de datos
});

db.connect(err => {
  if (err) {
    console.error('Error conectando a la BD:', err);
  } else {
    console.log('✅ Conectado a la base de datos');
  }
});

module.exports = db;
