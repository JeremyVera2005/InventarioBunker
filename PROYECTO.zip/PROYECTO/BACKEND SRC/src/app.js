const express = require('express');
const cors = require('cors');

// Rutas
const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const productoRoutes = require('./routes/producto.routes');
const proveedorRoutes = require('./routes/proveedor.routes');
const movimientoRoutes = require('./routes/movimiento.routes');

const app = express();

// Middlewares
app.use(cors({ origin: 'http://localhost:5173' })); // permite solicitudes desde tu frontend
app.use(express.json()); // para poder recibir JSON en el body

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/productos', productoRoutes);
app.use('/api/proveedores', proveedorRoutes);
app.use('/api/movimientos', movimientoRoutes);

module.exports = app;
