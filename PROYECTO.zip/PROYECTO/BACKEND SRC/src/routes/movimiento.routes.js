const express = require("express");
const router = express.Router();
const movimientoController = require("../controllers/movimiento.controller");

// Obtener todos los movimientos
router.get("/", movimientoController.getMovimientos);

// Registrar movimiento
router.post("/", movimientoController.registrarMovimiento);

// Actualizar movimiento
router.put("/:id", movimientoController.updateMovimiento);

// Eliminar movimiento
router.delete("/:id", movimientoController.deleteMovimiento);

module.exports = router;
