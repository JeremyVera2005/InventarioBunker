const express = require("express");
const router = express.Router();
const productoController = require("../controllers/producto.controller");

// Obtener todos los productos
router.get("/", productoController.getAll);

// Crear producto
router.post("/", productoController.create);

// Actualizar producto
router.put("/:id", productoController.update);

// Eliminar producto
router.delete("/:id", productoController.delete);

module.exports = router;
