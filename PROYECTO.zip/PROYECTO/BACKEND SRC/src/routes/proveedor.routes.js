const express = require("express");
const router = express.Router();
const proveedorController = require("../controllers/proveedor.controller");

// Obtener todos los proveedores
router.get("/", proveedorController.getAll);

// Crear proveedor
router.post("/", proveedorController.create);

// Actualizar proveedor
router.put("/:id", proveedorController.update);

// Eliminar proveedor
router.delete("/:id", proveedorController.delete);

module.exports = router;
