import { useEffect, useState } from "react";
import {
  getMovimientos,
  createMovimiento,
  deleteMovimiento,
  updateMovimiento,
} from "../services/movimientoService";
import { getProductos } from "../services/productoService";
import { Search, Package, FileText, Hash } from "lucide-react";
import Swal from "sweetalert2";

const Movimientos = () => {
  const [movimientos, setMovimientos] = useState([]);
  const [productos, setProductos] = useState([]);
  const [form, setForm] = useState({ id: null, tipo: "", cantidad: "", productoNombre: "" });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [search, setSearch] = useState("");

  // Cargar movimientos
  const fetchMovimientos = async () => {
    try {
      const data = await getMovimientos();
      setMovimientos(data);
    } catch (err) {
      console.error("Error al obtener movimientos:", err);
      Swal.fire("Error", "❌ No se pudieron cargar los movimientos", "error");
    }
  };

  // Cargar productos
  const fetchProductos = async () => {
    try {
      const data = await getProductos();
      setProductos(data);
    } catch (err) {
      console.error("Error al obtener productos:", err);
      Swal.fire("Error", "❌ No se pudieron cargar los productos", "error");
    }
  };

  useEffect(() => {
    fetchMovimientos();
    fetchProductos();
  }, []);

  // Guardar o editar
  const handleSave = async () => {
    if (!form.tipo || !form.cantidad || !form.productoNombre) {
      Swal.fire("Campos vacíos", "⚠️ Todos los campos son obligatorios", "warning");
      return;
    }

    try {
      if (form.id) {
        // Editar
        await updateMovimiento(form.id, {
          producto_nombre: form.productoNombre,
          tipo: form.tipo,
          cantidad: parseInt(form.cantidad),
        });
        Swal.fire("Actualizado", "✏️ Movimiento actualizado con éxito", "success");
      } else {
        // Crear
        await createMovimiento({
          producto_nombre: form.productoNombre,
          tipo: form.tipo,
          cantidad: parseInt(form.cantidad),
        });
        Swal.fire("Creado", "✅ Movimiento registrado con éxito", "success");
      }

      setForm({ id: null, tipo: "", cantidad: "", productoNombre: "" });
      setIsModalOpen(false);
      fetchMovimientos();
    } catch (err) {
      console.error("Error al guardar movimiento:", err.response?.data || err.message);
      Swal.fire("Error", "❌ No se pudo guardar el movimiento", "error");
    }
  };

  // Eliminar
  const handleDelete = async (id) => {
    Swal.fire({
      title: "¿Estás seguro?",
      text: "No podrás revertir esto",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await deleteMovimiento(id);
          Swal.fire("Eliminado", "🗑️ Movimiento eliminado", "success");
          fetchMovimientos();
        } catch (err) {
          console.error("Error al eliminar movimiento:", err.response?.data || err.message);
          Swal.fire("Error", "❌ No se pudo eliminar el movimiento", "error");
        }
      }
    });
  };

  // Abrir modal en modo edición
  const handleEdit = (mov) => {
    setForm({
      id: mov.id,
      tipo: mov.tipo,
      cantidad: mov.cantidad,
      productoNombre: mov.producto_nombre,
    });
    setIsModalOpen(true);
  };

  // Filtrar
  const movimientosFiltrados = movimientos.filter((m) =>
    `${m.tipo} ${m.cantidad} ${m.producto_nombre || ""}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <section className="mt-6 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-black/5">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h4 className="text-base font-semibold">Gestión de Movimientos</h4>

        {/* Barra de búsqueda */}
        <div className="relative w-full md:w-1/3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Buscar movimiento..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <button
          onClick={() => {
            setForm({ id: null, tipo: "", cantidad: "", productoNombre: "" });
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
        >
          <i className="fa-solid fa-plus"></i> Agregar Movimiento
        </button>
      </div>

      {/* Tabla */}
      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-left text-sm border border-slate-200 rounded-lg overflow-hidden bg-white">
          <thead className="bg-emerald-600 text-white">
            <tr>
              <th className="px-3 py-3">Producto</th>
              <th className="px-3 py-3">Tipo</th>
              <th className="px-3 py-3">Cantidad</th>
              <th className="px-3 py-3">Fecha</th>
              <th className="px-3 py-3 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {movimientosFiltrados.map((m, i) => (
              <tr key={m.id} className={i % 2 === 0 ? "bg-white" : "bg-slate-50"}>
                <td className="px-3 py-3">{m.producto_nombre || "—"}</td>
                <td className="px-3 py-3">{m.tipo}</td>
                <td className="px-3 py-3">{m.cantidad}</td>
                <td className="px-3 py-3">{m.fecha}</td>
                <td className="px-3 py-3 text-center flex gap-2 justify-center">
                  <button
                      onClick={() => handleEdit(m)}
                      className="flex items-center gap-2 rounded-lg bg-amber-500 px-3 py-2 text-sm font-semibold text-white hover:bg-amber-600"
                    >
                      <i className="fa-solid fa-pen"></i> Editar
                  </button>
                  <button
                    onClick={() => handleDelete(m.id)}
                    className="flex items-center gap-2 rounded-lg bg-rose-600 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-700"
                  >
                    <i className="fa-solid fa-trash"></i> Eliminar
                  </button>
                </td>
              </tr>
            ))}
            {movimientosFiltrados.length === 0 && (
              <tr>
                <td colSpan="5" className="text-center py-6 text-slate-500">
                  No se encontraron movimientos
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
          <div className="bg-white rounded-xl p-6 shadow-lg w-full max-w-md">
            <h3 className="text-lg font-semibold mb-6">
              {form.id ? "Editar Movimiento" : "Agregar Movimiento"}
            </h3>

            <div className="space-y-4">
              {/* Tipo */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <FileText className="text-gray-500 mr-3" size={20} />
                <select
                  value={form.tipo}
                  onChange={(e) => setForm({ ...form, tipo: e.target.value })}
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                >
                  <option value="">Seleccione tipo</option>
                  <option value="Ingreso">Ingreso</option>
                  <option value="Salida">Salida</option>
                </select>
              </div>

              {/* Cantidad */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <Hash className="text-gray-500 mr-3" size={20} />
                <input
                  type="number"
                  value={form.cantidad}
                  onChange={(e) => setForm({ ...form, cantidad: e.target.value })}
                  placeholder="Cantidad"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>

              {/* Producto */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <Package className="text-gray-500 mr-3" size={20} />
                <select
                  value={form.productoNombre}
                  onChange={(e) => setForm({ ...form, productoNombre: e.target.value })}
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                >
                  <option value="">Seleccione un producto</option>
                  {productos.map((prod) => (
                    <option key={prod.id} value={prod.nombre}>
                      {prod.nombre}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Botones */}
            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 rounded-lg bg-gray-300 hover:bg-gray-400 text-gray-800"
              >
                Cancelar
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
              >
                {form.id ? "Actualizar" : "Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Movimientos;
