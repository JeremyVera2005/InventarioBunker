import { useEffect, useState } from "react";
import { getProveedores, createProveedor, updateProveedor, deleteProveedor } from "../services/proveedorService";
import { Building2, Phone, User, Search } from "lucide-react";
import Swal from "sweetalert2";

const Proveedores = () => {
  const [proveedores, setProveedores] = useState([]);
  const [form, setForm] = useState({ nombre: "", contacto: "", telefono: "" });
  const [search, setSearch] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editProveedor, setEditProveedor] = useState(null);

  const fetchProveedores = async () => {
    try {
      const data = await getProveedores();
      setProveedores(data);
    } catch (err) {
      console.error("Error al obtener proveedores:", err);
      Swal.fire("Error", "❌ No se pudieron cargar los proveedores", "error");
    }
  };

  useEffect(() => {
    fetchProveedores();
  }, []);

  const handleSave = async () => {
    if (!form.nombre || !form.contacto || !form.telefono) {
      Swal.fire("Campos vacíos", "⚠️ Todos los campos son obligatorios", "warning");
      return;
    }

    try {
      if (editProveedor) {
        await updateProveedor(editProveedor.id, form);
        Swal.fire("Actualizado", "✏️ Proveedor actualizado con éxito", "success");
      } else {
        await createProveedor(form);
        Swal.fire("Creado", "✅ Proveedor agregado con éxito", "success");
      }

      setForm({ nombre: "", contacto: "", telefono: "" });
      setEditProveedor(null);
      setIsModalOpen(false);
      fetchProveedores();
    } catch (err) {
      console.error("Error al guardar proveedor:", err.response?.data || err.message);
      Swal.fire("Error", "❌ No se pudo guardar el proveedor", "error");
    }
  };

  const handleDelete = async (id) => {
    Swal.fire({
      title: "¿Estás seguro?",
      text: "No podrás revertir esto",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await deleteProveedor(id);
          Swal.fire("Eliminado", "🗑️ Proveedor eliminado con éxito", "success");
          fetchProveedores();
        } catch (err) {
          console.error("Error al eliminar proveedor:", err.response?.data || err.message);
          Swal.fire("Error", "❌ No se pudo eliminar el proveedor", "error");
        }
      }
    });
  };

  const proveedoresFiltrados = proveedores.filter((p) =>
    `${p.nombre} ${p.contacto} ${p.telefono}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <section className="mt-6 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-black/5">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h4 className="text-base font-semibold">Gestión de Proveedores</h4>

        {/* Barra de búsqueda */}
        <div className="relative w-full md:w-1/3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Buscar proveedor..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <button
          onClick={() => {
            setForm({ nombre: "", contacto: "", telefono: "" });
            setEditProveedor(null);
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
        >
          <i className="fa-solid fa-plus"></i> Agregar Proveedor
        </button>
      </div>

      {/* Tabla */}
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-sm border border-slate-200 rounded-lg overflow-hidden bg-white">
          <thead className="bg-emerald-600 text-white">
            <tr>
              <th className="px-3 py-3">Nombre</th>
              <th className="px-3 py-3">Contacto</th>
              <th className="px-3 py-3">Teléfono</th>
              <th className="px-3 py-3 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {proveedoresFiltrados.map((p, i) => (
              <tr
                key={p.id}
                className={`transition-colors ${i % 2 === 0 ? "bg-white" : "bg-slate-50"} hover:bg-emerald-50`}
              >
                <td className="px-3 py-3 font-medium text-slate-700">{p.nombre}</td>
                <td className="px-3 py-3 text-slate-600">{p.contacto}</td>
                <td className="px-3 py-3 text-slate-600">{p.telefono}</td>
                <td className="px-3 py-3 text-center flex gap-2 justify-center">
                  <button
                    onClick={() => {
                      setForm({ nombre: p.nombre, contacto: p.contacto, telefono: p.telefono });
                      setEditProveedor(p);
                      setIsModalOpen(true);
                    }}
                    className="flex items-center gap-2 rounded-lg bg-amber-500 px-3 py-2 text-sm font-semibold text-white hover:bg-amber-600"
                  >
                    <i className="fa-solid fa-pen"></i> Editar
                  </button>
                  <button
                    onClick={() => handleDelete(p.id)}
                    className="flex items-center gap-2 rounded-lg bg-rose-600 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-700"
                  >
                    <i className="fa-solid fa-trash"></i> Eliminar
                  </button>
                </td>
              </tr>
            ))}
            {proveedoresFiltrados.length === 0 && (
              <tr>
                <td colSpan="4" className="px-3 py-6 text-center text-slate-500">
                  No se encontraron proveedores
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
          <div className="bg-white rounded-xl p-6 shadow-lg w-full max-w-md">
            <h3 className="text-lg font-semibold mb-6">
              {editProveedor ? "Editar Proveedor" : "Agregar Proveedor"}
            </h3>

            <div className="space-y-4">
              <div className="flex items-center border-b border-gray-400 py-2">
                <Building2 className="text-gray-500 mr-3" size={20} />
                <input
                  value={form.nombre}
                  onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                  placeholder="Nombre"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>

              <div className="flex items-center border-b border-gray-400 py-2">
                <User className="text-gray-500 mr-3" size={20} />
                <input
                  value={form.contacto}
                  onChange={(e) => setForm({ ...form, contacto: e.target.value })}
                  placeholder="Contacto"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>

              <div className="flex items-center border-b border-gray-400 py-2">
                <Phone className="text-gray-500 mr-3" size={20} />
                <input
                  value={form.telefono}
                  onChange={(e) => setForm({ ...form, telefono: e.target.value })}
                  placeholder="Teléfono"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setEditProveedor(null);
                }}
                className="px-4 py-2 rounded-lg bg-gray-300 hover:bg-gray-400 text-gray-800"
              >
                Cancelar
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
              >
                {editProveedor ? "Actualizar" : "Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Proveedores;
