import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from '../services/authService';
import { Mail, Lock } from "lucide-react"; // librería de íconos (instalar con: npm install lucide-react)

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = await login(email, password);
      localStorage.setItem('token', data.token);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.error || 'Error en login');
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      <div className="relative w-96">
        
        {/* Círculo flotante con imagen */}
        <div className="absolute -top-20 left-1/2 transform -translate-x-1/2">
          <div className="w-40 h-40 bg-black rounded-full flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
            <img 
              src="/Logo-Bunker.png"   
              alt="User" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Formulario */}
        <form 
          onSubmit={handleSubmit} 
          className="bg-white p-8 rounded-xl shadow-lg pt-28"
        >
          <h2 className="text-2xl font-bold text-gray-800 mb-8 text-center">Welcome</h2>

          {error && <p className="text-red-500 mb-2">{error}</p>}

          {/* Input Email */}
          <div className="flex items-center border-b border-gray-400 mb-6 py-2">
            <Mail className="text-gray-500 mr-3" size={20} />
            <input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full bg-transparent focus:outline-none text-gray-700"
            />
          </div>

          {/* Input Password */}
          <div className="flex items-center border-b border-gray-400 mb-6 py-2">
            <Lock className="text-gray-500 mr-3" size={20} />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full bg-transparent focus:outline-none text-gray-700"
            />
          </div>

          <div className="flex justify-between items-center w-full text-sm text-gray-600 mb-6">
            <label className="flex items-center">
              <input type="checkbox" className="mr-2 accent-black" />
              Remember
            </label>
            <a href="#" className="text-gray-500 hover:underline">Forgot Password?</a>
          </div>

          <button 
            type="submit" 
            className="w-full bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
