import { useEffect, useState } from "react";
import { getUsers, createUser, updateUser, deleteUser } from "../services/userService";
import { User, Mail, Lock, Search } from "lucide-react";
import Swal from "sweetalert2";

const Usuarios = () => {
  const [usuarios, setUsuarios] = useState([]);
  const [showPasswords, setShowPasswords] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [search, setSearch] = useState(""); // 👈 Nuevo estado para la búsqueda
  const [form, setForm] = useState({
    nombre: "",
    apellido: "",
    email: "",
    password: "",
    rol: "admin",
  });

  const fetchUsers = async () => {
    try {
      const data = await getUsers();
      setUsuarios(data);
    } catch (err) {
      console.error("❌ Error al cargar usuarios:", err.message);
      Swal.fire("Error", "❌ No se pudieron cargar los usuarios", "error");
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleSave = async () => {
    if (!form.nombre || !form.apellido || !form.email || !form.password || !form.rol) {
      Swal.fire("Campos vacíos", "⚠️ Todos los campos son obligatorios", "warning");
      return;
    }

    try {
      if (editUser) {
        await updateUser(editUser.id, form);
        Swal.fire("Actualizado", "✏️ Usuario actualizado con éxito", "success");
      } else {
        await createUser(form);
        Swal.fire("Creado", "✅ Usuario creado con éxito", "success");
      }

      setForm({ nombre: "", apellido: "", email: "", password: "", rol: "admin" });
      setEditUser(null);
      setIsModalOpen(false);
      fetchUsers();
    } catch (err) {
      console.error("❌ Error al guardar usuario:", err.response?.data || err.message);
      Swal.fire("Error", "❌ " + (err.response?.data?.error || err.message), "error");
    }
  };

  const handleDelete = async (id) => {
    Swal.fire({
      title: "¿Estás seguro?",
      text: "No podrás revertir esto",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await deleteUser(id);
          Swal.fire("Eliminado", "🗑️ Usuario eliminado con éxito", "success");
          fetchUsers();
        } catch (err) {
          console.error("❌ Error al eliminar usuario:", err.response?.data || err.message);
          Swal.fire("Error", "❌ No se pudo eliminar el usuario", "error");
        }
      }
    });
  };

  const togglePassword = (id) => {
    setShowPasswords((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const openEditModal = (user) => {
    setForm({
      nombre: user.nombre,
      apellido: user.apellido,
      email: user.email,
      password: user.password,
      rol: user.rol,
    });
    setEditUser(user);
    setIsModalOpen(true);
  };

  // 👇 Filtrado de usuarios
  const usuariosFiltrados = usuarios.filter((u) =>
    `${u.nombre} ${u.apellido} ${u.email}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <section className="mt-6 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-black/5">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h4 className="text-base font-semibold">Gestión de Usuarios</h4>
        
        {/* 🔍 Barra de búsqueda */}
        <div className="relative w-full md:w-1/3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Buscar usuario..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <button
          onClick={() => {
            setForm({ nombre: "", apellido: "", email: "", password: "", rol: "admin" });
            setEditUser(null);
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
        >
          <i className="fa-solid fa-plus"></i> Agregar Usuario
        </button>
      </div>

      {/* Tabla */}
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[820px] text-left text-sm border border-slate-200 rounded-lg overflow-hidden bg-white">
          <thead className="bg-emerald-600 text-white">
            <tr>
              <th className="px-3 py-3">Nombre</th>
              <th className="px-3 py-3">Apellido</th>
              <th className="px-3 py-3">Email</th>
              <th className="px-3 py-3">Password</th>
              <th className="px-3 py-3">Rol</th>
              <th className="px-3 py-3 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {usuariosFiltrados.map((u, i) => (
              <tr
                key={u.id}
                className={`transition-colors ${
                  i % 2 === 0 ? "bg-white" : "bg-slate-50"
                } hover:bg-emerald-50`}
              >
                <td className="px-3 py-3 font-medium text-slate-700">{u.nombre}</td>
                <td className="px-3 py-3 text-slate-600">{u.apellido}</td>
                <td className="px-3 py-3 text-slate-600">{u.email}</td>
                <td className="px-3 py-3">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-700">
                      {showPasswords[u.id] ? u.password : "•••••••"}
                    </span>
                    <button
                      onClick={() => togglePassword(u.id)}
                      className="text-gray-500 hover:text-gray-800"
                    >
                      {showPasswords[u.id] ? (
                        <i className="fa-solid fa-eye-slash"></i>
                      ) : (
                        <i className="fa-solid fa-eye"></i>
                      )}
                    </button>
                  </div>
                </td>
                <td className="px-3 py-3 text-slate-600">{u.rol}</td>
                <td className="px-3 py-3 text-center flex gap-2 justify-center">
                  <button
                    onClick={() => openEditModal(u)}
                    className="flex items-center gap-2 rounded-lg bg-amber-500 px-3 py-2 text-sm font-semibold text-white hover:bg-amber-600"
                  >
                    <i className="fa-solid fa-pen"></i> Editar
                  </button>
                  <button
                    onClick={() => handleDelete(u.id)}
                    className="flex items-center gap-2 rounded-lg bg-rose-600 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-700"
                  >
                    <i className="fa-solid fa-trash"></i> Eliminar
                  </button>
                </td>
              </tr>
            ))}
            {usuariosFiltrados.length === 0 && (
              <tr>
                <td colSpan="6" className="px-3 py-6 text-center text-slate-500">
                  No se encontraron usuarios
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
          <div className="bg-white rounded-xl p-6 shadow-lg w-full max-w-md">
            <h3 className="text-lg font-semibold mb-6">
              {editUser ? "Editar Usuario" : "Agregar Usuario"}
            </h3>

            <div className="space-y-4">
              {/* Nombre */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <User className="text-gray-500 mr-3" size={20} />
                <input
                  value={form.nombre}
                  onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                  placeholder="Nombre"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>

              {/* Apellido */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <User className="text-gray-500 mr-3" size={20} />
                <input
                  value={form.apellido}
                  onChange={(e) => setForm({ ...form, apellido: e.target.value })}
                  placeholder="Apellido"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>

              {/* Email */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <Mail className="text-gray-500 mr-3" size={20} />
                <input
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="Email"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>

              {/* Password */}
              <div className="flex items-center border-b border-gray-400 py-2 relative">
                <Lock className="text-gray-500 mr-3" size={20} />
                <input
                  type={showPasswordModal ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder="Password"
                  className="w-full bg-transparent focus:outline-none text-gray-700 pr-8"
                />
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(!showPasswordModal)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500"
                >
                  {showPasswordModal ? (
                    <i className="fa-solid fa-eye-slash"></i>
                  ) : (
                    <i className="fa-solid fa-eye"></i>
                  )}
                </button>
              </div>

              {/* Rol */}
              <select
                value={form.rol}
                onChange={(e) => setForm({ ...form, rol: e.target.value })}
                className="w-full border rounded-lg px-3 py-2 text-sm bg-white"
              >
                <option value="admin">Admin</option>
                <option value="vendedor">Vendedor</option>
              </select>
            </div>

            {/* Botones */}
            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setEditUser(null);
                }}
                className="px-4 py-2 rounded-lg bg-gray-300 hover:bg-gray-400 text-gray-800"
              >
                Cancelar
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
              >
                {editUser ? "Actualizar" : "Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Usuarios;
