// src/pages/DashboardContent.jsx
import { useState } from "react";

const DashboardContent = () => {
  const [filter, setFilter] = useState("");

  const data = [
    { id: "A-10234", cliente: "María Torres", prod: "Curso Excel", fecha: "01/09/2025", estado: "Pagado", total: 289 },
    { id: "A-10235", cliente: "Jorge Pérez", prod: "Curso IA", fecha: "01/09/2025", estado: "Pendiente", total: 199 },
    { id: "A-10236", cliente: "Lucía Ramos", prod: "AutoCAD", fecha: "31/08/2025", estado: "Pagado", total: 149 },
    { id: "A-10237", cliente: "Carlos Ruiz", prod: "Revit/BIM", fecha: "31/08/2025", estado: "Reembolsado", total: 149 },
    { id: "A-10238", cliente: "Ana Salas", prod: "SQL", fecha: "30/08/2025", estado: "Pagado", total: 129 },
    { id: "A-10239", cliente: "Kevin Rojas", prod: "Marketing Digital", fecha: "30/08/2025", estado: "Pagado", total: 159 },
  ];

  const filtered = data.filter((d) =>
    d.cliente.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <main className="mx-auto max-w-7xl px-4 py-6">
      {/* KPIs */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <article className="rounded-2xl bg-white p-4 shadow-soft ring-1 ring-black/5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs uppercase tracking-widest text-slate-500">
                Total Ventas
              </p>
              <h3 className="mt-1 text-2xl font-bold">S/ 128,450</h3>
            </div>
            <span className="rounded-md bg-emerald-50 px-2 py-1 text-xs font-semibold text-emerald-700">
              +12.4%
            </span>
          </div>
          <svg
            viewBox="0 0 120 40"
            className="mt-3 h-12 w-full text-emerald-500"
          >
            <polyline
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              points="0,28 15,26 30,22 45,24 60,18 75,14 90,20 105,12 120,16"
            />
          </svg>
        </article>

        <article className="rounded-2xl bg-white p-4 shadow-soft ring-1 ring-black/5">
          <p className="text-xs uppercase tracking-widest text-slate-500">
            Órdenes
          </p>
          <h3 className="mt-1 text-2xl font-bold">1,208</h3>
          <p className="mt-2 text-xs text-slate-500">Promedio diario 86</p>
        </article>

        <article className="rounded-2xl bg-white p-4 shadow-soft ring-1 ring-black/5">
          <p className="text-xs uppercase tracking-widest text-slate-500">
            Tasa de Conversión
          </p>
          <h3 className="mt-1 text-2xl font-bold">3.8%</h3>
          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-200">
            <div className="h-full w-[38%] rounded-full bg-blue-500"></div>
          </div>
        </article>

        <article className="rounded-2xl bg-white p-4 shadow-soft ring-1 ring-black/5">
          <p className="text-xs uppercase tracking-widest text-slate-500">
            Ticket Promedio
          </p>
          <h3 className="mt-1 text-2xl font-bold">S/ 106.34</h3>
          <p className="mt-2 text-xs text-emerald-600">▲ estable</p>
        </article>
      </section>

      {/* Gráfica + Top productos */}
      <section className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="rounded-2xl bg-white p-4 shadow-soft ring-1 ring-black/5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h4 className="text-base font-semibold">
              Ventas de los últimos 30 días
            </h4>
            <div className="flex items-center gap-2 text-xs">
              <button className="rounded-md border px-2 py-1 hover:bg-slate-50">
                Día
              </button>
              <button className="rounded-md border px-2 py-1 hover:bg-slate-50">
                Semana
              </button>
              <button className="rounded-md border bg-blue-600 px-2 py-1 text-white">
                Mes
              </button>
            </div>
          </div>
          <div className="mt-4 h-64 w-full">
            <svg viewBox="0 0 700 240" className="h-full w-full">
              <defs>
                <linearGradient id="grad" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#3f77ff" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#3f77ff" stopOpacity="0" />
                </linearGradient>
              </defs>
              <polyline
                fill="url(#grad)"
                stroke="#3f77ff"
                strokeWidth="2"
                points="0,180 40,176 80,170 120,160 160,152 200,140 240,150 280,132 320,120 360,126 400,110 440,98 480,112 520,96 560,86 600,94 640,80 680,86 700,84 700,240 0,240"
              />
            </svg>
          </div>
        </div>

        <div className="rounded-2xl bg-white p-4 shadow-soft ring-1 ring-black/5">
          <h4 className="text-base font-semibold">Top Productos</h4>
          <ul className="mt-3 divide-y">
            <li className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <span className="h-8 w-8 rounded-lg bg-slate-100"></span>
                <span className="text-sm">Curso Excel</span>
              </div>
              <span className="text-sm font-semibold">S/ 28,900</span>
            </li>
            <li className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <span className="h-8 w-8 rounded-lg bg-slate-100"></span>
                <span className="text-sm">Curso IA</span>
              </div>
              <span className="text-sm font-semibold">S/ 24,300</span>
            </li>
            <li className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <span className="h-8 w-8 rounded-lg bg-slate-100"></span>
                <span className="text-sm">Revit/BIM</span>
              </div>
              <span className="text-sm font-semibold">S/ 19,120</span>
            </li>
          </ul>
          <button className="mt-3 w-full rounded-lg border px-3 py-2 text-sm hover:bg-slate-50">
            Ver todos
          </button>
        </div>
      </section>

      {/* Tabla de órdenes */}
      <section className="mt-6 rounded-2xl bg-white p-4 shadow-soft ring-1 ring-black/5">
        <div className="items-center justify-between gap-3 sm:flex">
          <h4 className="text-base font-semibold">Órdenes recientes</h4>
          <div className="mt-3 flex items-center gap-2 sm:mt-0">
            <input
              type="text"
              placeholder="Filtrar por cliente…"
              className="w-56 rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
            <button className="rounded-lg bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700">
              Exportar
            </button>
          </div>
        </div>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="text-xs uppercase tracking-wider text-slate-500">
              <tr>
                <th className="px-3 py-2"># Orden</th>
                <th className="px-3 py-2">Cliente</th>
                <th className="px-3 py-2">Producto</th>
                <th className="px-3 py-2">Fecha</th>
                <th className="px-3 py-2">Estado</th>
                <th className="px-3 py-2 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50">
                  <td className="px-3 py-3 font-medium">{r.id}</td>
                  <td className="px-3 py-3">{r.cliente}</td>
                  <td className="px-3 py-3">{r.prod}</td>
                  <td className="px-3 py-3">{r.fecha}</td>
                  <td className="px-3 py-3">
                    <span
                      className={`rounded-full px-2 py-1 text-xs font-semibold ${
                        r.estado === "Pagado"
                          ? "bg-emerald-50 text-emerald-700"
                          : r.estado === "Pendiente"
                          ? "bg-amber-50 text-amber-700"
                          : "bg-rose-50 text-rose-700"
                      }`}
                    >
                      {r.estado}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-right font-semibold">
                    S/ {r.total.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
};

export default DashboardContent;
