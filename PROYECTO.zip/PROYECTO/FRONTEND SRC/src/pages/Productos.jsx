import { useEffect, useState } from "react";
import { getProductos, createProducto, updateProducto, deleteProducto } from "../services/productoService";
import { getProveedores } from "../services/proveedorService";
import { Package, DollarSign, Truck, Search } from "lucide-react";
import Swal from "sweetalert2";

const Productos = () => {
  const [productos, setProductos] = useState([]);
  const [proveedores, setProveedores] = useState([]);
  const [form, setForm] = useState({ nombre: "", precio: "", proveedor: "" });
  const [editProducto, setEditProducto] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [search, setSearch] = useState(""); // 🔍 nuevo estado de búsqueda

  const fetchProductos = async () => {
    try {
      const data = await getProductos();
      setProductos(data);
    } catch (err) {
      console.error("Error al obtener productos:", err);
      Swal.fire("Error", "❌ No se pudieron cargar los productos", "error");
    }
  };

  const fetchProveedores = async () => {
    try {
      const data = await getProveedores();
      setProveedores(data);
    } catch (err) {
      console.error("Error al obtener proveedores:", err);
      Swal.fire("Error", "❌ No se pudieron cargar los proveedores", "error");
    }
  };

  useEffect(() => {
    fetchProductos();
    fetchProveedores();
  }, []);

  const handleSave = async () => {
    if (!form.nombre || !form.precio || !form.proveedor) {
      Swal.fire("Campos vacíos", "⚠️ Todos los campos son obligatorios", "warning");
      return;
    }

    try {
      if (editProducto) {
        await updateProducto(editProducto.id, { ...form });
        Swal.fire("Actualizado", "✏️ Producto actualizado con éxito", "success");
      } else {
        await createProducto({ ...form, stock: 0 });
        Swal.fire("Creado", "✅ Producto creado con éxito", "success");
      }

      setForm({ nombre: "", precio: "", proveedor: "" });
      setEditProducto(null);
      setIsModalOpen(false);
      fetchProductos();
    } catch (err) {
      console.error("Error al guardar producto:", err.response?.data || err.message);
      Swal.fire("Error", "❌ No se pudo guardar el producto", "error");
    }
  };

  const handleDelete = async (id) => {
    Swal.fire({
      title: "¿Estás seguro?",
      text: "No podrás revertir esto",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await deleteProducto(id);
          Swal.fire("Eliminado", "🗑️ Producto eliminado", "success");
          fetchProductos();
        } catch (err) {
          console.error("Error al eliminar producto:", err.response?.data || err.message);
          Swal.fire("Error", "❌ No se pudo eliminar el producto", "error");
        }
      }
    });
  };

  const openEditModal = (producto) => {
    setForm({
      nombre: producto.nombre,
      precio: producto.precio,
      proveedor: producto.proveedor,
    });
    setEditProducto(producto);
    setIsModalOpen(true);
  };

  // 🔍 Filtrar productos
  const productosFiltrados = productos.filter((p) =>
    `${p.nombre} ${p.precio} ${p.proveedor}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <section className="mt-6 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-black/5">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h4 className="text-base font-semibold">Gestión de Productos</h4>

        {/* Barra de búsqueda */}
        <div className="relative w-full md:w-1/3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Buscar producto..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <button
          onClick={() => {
            setForm({ nombre: "", precio: "", proveedor: "" });
            setEditProducto(null);
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
        >
          <i className="fa-solid fa-plus"></i> Agregar Producto
        </button>
      </div>

      {/* Tabla */}
      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-left text-sm border border-slate-200 rounded-lg overflow-hidden bg-white">
          <thead className="bg-emerald-600 text-white">
            <tr>
              <th className="px-3 py-3">Nombre</th>
              <th className="px-3 py-3">Precio</th>
              <th className="px-3 py-3">Stock</th>
              <th className="px-3 py-3">Proveedor</th>
              <th className="px-3 py-3 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {productosFiltrados.map((p, i) => (
              <tr key={p.id} className={i % 2 === 0 ? "bg-white" : "bg-slate-50"}>
                <td className="px-3 py-3">{p.nombre}</td>
                <td className="px-3 py-3">{p.precio}</td>
                <td className="px-3 py-3">{p.stock}</td>
                <td className="px-3 py-3">{p.proveedor || "—"}</td>
                <td className="px-3 py-3 text-center flex gap-2 justify-center">
                  <button
                    onClick={() => openEditModal(p)}
                    className="flex items-center gap-2 rounded-lg bg-amber-500 px-3 py-2 text-sm font-semibold text-white hover:bg-amber-600"
                  >
                    <i className="fa-solid fa-pen"></i> Editar
                  </button>
                  <button
                    onClick={() => handleDelete(p.id)}
                    className="flex items-center gap-2 rounded-lg bg-rose-600 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-700"
                  >
                    <i className="fa-solid fa-trash"></i> Eliminar
                  </button>
                </td>
              </tr>
            ))}
            {productosFiltrados.length === 0 && (
              <tr>
                <td colSpan="5" className="text-center py-6 text-slate-500">
                  No se encontraron productos
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
          <div className="bg-white rounded-xl p-6 shadow-lg w-full max-w-md">
            <h3 className="text-lg font-semibold mb-6">
              {editProducto ? "Editar Producto" : "Agregar Producto"}
            </h3>

            <div className="space-y-4">
              {/* Nombre */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <Package className="text-gray-500 mr-3" size={20} />
                <input
                  value={form.nombre}
                  onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                  placeholder="Nombre del producto"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>

              {/* Precio */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <DollarSign className="text-gray-500 mr-3" size={20} />
                <input
                  type="number"
                  value={form.precio}
                  onChange={(e) => setForm({ ...form, precio: e.target.value })}
                  placeholder="Precio"
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                />
              </div>

              {/* Proveedor */}
              <div className="flex items-center border-b border-gray-400 py-2">
                <Truck className="text-gray-500 mr-3" size={20} />
                <select
                  value={form.proveedor}
                  onChange={(e) => setForm({ ...form, proveedor: e.target.value })}
                  className="w-full bg-transparent focus:outline-none text-gray-700"
                >
                  <option value="">Seleccione un proveedor</option>
                  {proveedores.map((prov) => (
                    <option key={prov.id} value={prov.nombre}>
                      {prov.nombre}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Botones */}
            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setEditProducto(null);
                }}
                className="px-4 py-2 rounded-lg bg-gray-300 hover:bg-gray-400 text-gray-800"
              >
                Cancelar
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
              >
                {editProducto ? "Actualizar" : "Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Productos;
