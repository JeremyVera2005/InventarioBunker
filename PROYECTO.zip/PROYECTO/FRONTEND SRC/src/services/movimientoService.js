import axios from "axios";

const API = "http://localhost:5000/api/movimientos";

export const getMovimientos = () => axios.get(API).then(res => res.data);

export const createMovimiento = (movimiento) =>
  axios.post(API, movimiento).then(res => res.data);

export const deleteMovimiento = (id) =>
  axios.delete(`${API}/${id}`).then(res => res.data);

// 🆕 Editar movimiento
export const updateMovimiento = (id, movimiento) =>
  axios.put(`${API}/${id}`, movimiento).then(res => res.data);