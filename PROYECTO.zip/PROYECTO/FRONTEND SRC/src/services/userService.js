import axios from "axios";
const API = "http://localhost:5000/api/users";

export const getUsers = () => axios.get(API).then(res => res.data);
export const createUser = (user) => axios.post(API, user);
export const updateUser = (id, user) => axios.put(`${API}/${id}`, user);
export const deleteUser = (id) => axios.delete(`${API}/${id}`);
