import axios from "axios";
const API = "http://localhost:5000/api/proveedores";

export const getProveedores = () => axios.get(API).then(res => res.data);
export const createProveedor = (proveedor) => axios.post(API, proveedor);
export const updateProveedor = (id, proveedor) => axios.put(`${API}/${id}`, proveedor);
export const deleteProveedor = (id) => axios.delete(`${API}/${id}`);
